*Observações:

-O programa pode demorar um pouco para abrir ou parar de funcionar, mas ele abre eventualmente.

-Adicionar fichas na pasta "fichas", elas devem estar no formato .txt e seguirem 
o formato dos exemplos ja inclusos na pasta, se desejado as fichas de exemplo
podem ser removidas.

-Por enquanto o programa não atualiza a lista de fichas em tempo real, para adicionar 
novas fichas ou modificar fichas existentes precisa fechar o programa, adicionar a ficha 
na pasta "fichas" e abrir o programa novamente.

-Por enquanto o sistema de combate esta simples, aceitando apenas 1 atacante e 1
defensor, o defensor irá sempre rolar esquiva, e o atacante irá sempre rolar ataque
físico comum.

*Bugs:

-(resolvido)Se um stat não for multiplo de 2 os modificadores não são aplicados 
corretamente.